import React from 'react'
import './WelcomePage.css'


const WelcomePage = () => {
    return (
        <div className="welcomePage">
            <h1>Hello World</h1>
        </div>
    )
}

export default WelcomePage
