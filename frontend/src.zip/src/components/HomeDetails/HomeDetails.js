import React, { useState, useEffect, useLayoutEffect } from 'react';
import { BsEnvelope } from 'react-icons/bs';
import './HomeDetails.css';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { FaBed, FaBath, FaRegBuilding, FaRegHeart } from 'react-icons/fa';
import { TiTickOutline } from 'react-icons/ti';
import bill from './bills.png';
import { useHistory } from 'react-router-dom';
import { IoIosArrowBack } from 'react-icons/io';
import { BiLeftArrow } from "react-icons/bi";
import { BiRightArrow } from "react-icons/bi";


export default function HomeDetails() {
	useLayoutEffect(() => {
		window.scrollTo(0, 0);
	}, []);

	let history = useHistory();

	const [bookViewing, setBookViewing] = useState(false);

	
	

	const { id } = useParams();
	const [home, setHome] = useState([]);
	const[firstImg,setFirstImg]=useState(null)
	const[secondImg,setSecondImg]=useState(null)
	const[thirdImg,setThirdImg]=useState(null)
	const[fourthImg,setFourthImg]=useState(null)

	// useEffect(() => {
	// 	if(home.images.length!==0){
	// 		setFirstImg(home.images[0].url)
	// 	}
		
	// }, [])
	
	// const [rowsOfBedroomPrices, setRowsOfBedroomPrices] = useState([]);

	useEffect(() => {
		axios
			.get(`http://localhost:5000/homes/${id}`)
			.then((res) => {setFirstImg(res.data.images[0]); 
				setSecondImg(res.data.images[1]);
				setThirdImg(res.data.images[2]);
				setFourthImg(res.data.images[3]);
				setHome(res.data)})
			.catch((err) => console.log(err));
	}, [id]);

	const showBookViewing = () => {
		setBookViewing(!bookViewing);
	};

	const closeBookViewing = () => {
		setBookViewing(false);
	};

	// useEffect(() => {
	// 	for (let i = 1; i <= home.bedroom; i++) {
	// 		setRowsOfBedroomPrices([...rowsOfBedroomPrices, `row${i}`]);
	// 	}

	// 	console.log(rowsOfBedroomPrices);
	// }, []);

	const handleSecondImg=()=>{
		setFirstImg(secondImg)
		setFourthImg(firstImg)
		setSecondImg(thirdImg)
		setThirdImg(fourthImg)
	}
	const handleThirdImg=()=>{
		setFirstImg(thirdImg)
		setFourthImg(firstImg)
		setSecondImg(secondImg)
		setThirdImg(fourthImg)
	}
	const handleFourthImg=()=>{
		setFirstImg(fourthImg)
		setFourthImg(firstImg)
		setSecondImg(secondImg)
		setThirdImg(thirdImg)
	}
	const handleRightSwipe=()=>{
		setFirstImg(secondImg)
		setFourthImg(firstImg)
		setSecondImg(thirdImg)
		setThirdImg(fourthImg)
	}
	const handleLeftSwipe=()=>{
		setFirstImg(fourthImg)
		setFourthImg(thirdImg)
		setSecondImg(firstImg)
		setThirdImg(secondImg)
	}

	return (
		<div>
			
			<div className="homedetails-back-to-search">
				<form>
					<button
						className="homedetails-back-to-search-btn"
						onClick={(e) => {
							e.preventDefault();
							history.goBack();
						}}
					>
						<IoIosArrowBack size={12} />
						Back to Search
					</button>
				</form>
			</div>

			<div className="homedetails-container">

				<div className="homedetails-container-main">
					<div className="homedetails-main-img">
					
					<div style={{position:"relative"}}>
					<BiRightArrow onClick={handleRightSwipe} size={40} fill="white" style={{position:"absolute",top:"45%",right:"2%"}} />
					<BiLeftArrow onClick={handleLeftSwipe} size={40} fill="white" style={{position:"absolute",top:"45%",left:"2%"}} />
					<img  src={firstImg && firstImg} style={{borderRadius:"3px"}} alt=""/> 
					</div>
					   
					   <div style={{display:"flex",justifyContent:"space-around"}}>
							<img onClick={handleSecondImg} src={secondImg} alt="" style={{height:"auto",width:"30%",margin:"1%",flex:4,borderRadius:"3px"}} />
							<img  onClick={handleThirdImg} src={thirdImg} alt="" style={{height:"auto",width:"30%",margin:"1%",flex:4,borderRadius:"3px"}}/>
							<img onClick={handleFourthImg} src={fourthImg} alt="" style={{height:"auto",width:"30%",margin:"1%",flex:4,borderRadius:"3px"}} />
						</div>   
						
					</div>

					<div className="homedetails-main-key-features">
						<h3>Key Features</h3>
						{home.length !== 0 &&
							home.keyFeatures.map((keyFeature) => (
								<ul>
									<li>
										<TiTickOutline fill="#03c5f0" size={22} />
										{keyFeature}
									</li>
								</ul>
							))}
					</div>
					<div className="homedetails-main-bedroom-prices">
						<h3>Bedroom Prices</h3>
						{/* {rowsOfBedroomPrices.length !== 0 &&
							rowsOfBedroomPrices.map((index) => (
								<div key={index} style={{ border: 'solid 1px black' }}>
									{`Bedroom ${index + 1}`} {home.rent}
								</div>
							))} */}
					</div>
					<div className="homedetails-main-availability">
						<h3>Availability</h3>
						Till {home.availability}
					</div>
				</div>
				<div className="homedetails-sidebar-container">
					<div className="btn-book-viewing-container">
						<h3>
							{home.length !== 0 && home.address.street},{' '}
							{home.length !== 0 && home.address.district}
						</h3>
						<br />
						<h3>
							{home.length !== 0 && home.address.city},{' '}
							{home.length !== 0 && home.address.postcode}
						</h3>
						<div className="homedetails-rooms-count-type-container">
							<div className="homedetails-rooms-count-bedroom">
								<p>Bedrooms</p>
								<div style={{ textAlign: 'center' }}>
									<FaBed
										style={{
											fill: '#03c5f0',
											marginRight: 8,
											marginLeft: 8,
										}}
									/>
									{home.length !== 0 && home.bedroom}
								</div>
							</div>
							<div className="homedetails-rooms-count-bathroom">
								<p>Bathrooms</p>
								<div style={{ textAlign: 'center' }}>
									<FaBath
										style={{
											fill: '#03c5f0',
											marginRight: 8,
											marginLeft: 8,
										}}
									/>
									{home.length !== 0 && home.bathroom}
								</div>
							</div>
							<div className="homedetails-rooms-type">
								<p>Type</p>
								<div style={{ textAlign: 'center' }}>
									<FaRegBuilding
										style={{
											fill: '#03c5f0',
											marginRight: 5,
											marginLeft: 8,
										}}
									/>
									<span style={{ fontSize: 12 }}>
										{home.length !== 0 && home.type}
									</span>
								</div>
							</div>
						</div>
						<br />
						<hr />
						<h4
							style={{
								textAlign: 'center',
								paddingTop: 8,
								paddingBottom: 8,
							}}
						>
							{home.rent} pppw including bills
						</h4>
						<hr />
						<br />
						<button
							className="btn-book-viewing"
							type="submit"
							onClick={showBookViewing}
						>
							<BsEnvelope style={{ fill: 'white', marginRight: 10 }} />
							Book Viewing
						</button>
						<div style={{ textAlign: 'center', marginBottom: 20 }}>
							<button className="homedetails-sidebar-btn-shortlist">
								<FaRegHeart style={{ fill: '#03c5f0' }} />
							</button>
						</div>
						<div style={{ textAlign: 'center' }}>
							<img
								src={bill}
								alt="bills"
								style={{ width: '75%', height: 'auto' }}
							/>
						</div>
					</div>
				</div>

				{bookViewing ? (
					<div className="book-viewing-container">
						<button
							className="btn-book-viewing-page-close"
							onClick={closeBookViewing}
						>
							X
						</button>
						<div className="book-viewing-form-container">
							<div>
								<h2 className="book-viewing-form-title">
									Book a Viewing
								</h2>
							</div>
							<div>
								<h4 className="book-viewing-form-address">Address</h4>
							</div>
							<div>
								<form className="book-viewing-form">
									<label>Name</label>
									<br />
									<input placeholder="Name" required />
									<br />
									<label>Email Address</label>
									<br />
									<input
										type="email"
										placeholder="name@email.com"
										required
									/>
									<br />
									<label>Phone Number</label>
									<br />
									<input placeholder="Phone number" required />
									<br />
									<label>Message</label>
									<br />
									<textarea
										style={{
											height: '72px',
											border: 'none',
											borderRadius: '3px',
										}}
										placeholder="Text message..."
										required
									/>
									<div className="book-viewing-check-box">
										<input type="checkbox" />
										<label>
											Tick here if you want to hear about university
											life, student accommodation and much more! See
											our{' '}
											<a
												href="/policies"
												style={{
													textDecoration: 'underline',
													color: 'white',
												}}
											>
												Privacy Policy
											</a>
										</label>
									</div>
									<button className="btn-book-viewing-page-form-submit">
										Submit
									</button>
								</form>
							</div>
						</div>
					</div>
				) : null}
			</div>
		</div>
	);
}
